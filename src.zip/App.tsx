import { useEffect, useMemo, useRef, useState } from "react";

function sunlight(hour: number) {
  return hour <= 6 || hour >= 18 ? 0 : Math.sin((Math.PI * (hour - 6)) / 12);
}

function ambientLight(hour: number, clouds: number) {
  return sunlight(hour) * (1 - (0.8 * clouds) / 100) * 100;
}

function pwmValue(hour: number, clouds: number) {
  return Math.max(1, Math.round(255 * (1 - ambientLight(hour, clouds) / 100)));
}

function calculateEnergy(hour: number, clouds: number, power: number) {
  let smart = 0;
  let traditional = 0;
  const step = 0.02;

  for (let current = 0; current < hour; current += step) {
    smart += (power * pwmValue(current, clouds) * step) / 255;
    traditional += power * step;
  }

  return { smart, traditional };
}

function formatHour(hour: number) {
  const totalMinutes = Math.round(hour * 60);
  if (totalMinutes >= 1440) return "24:00";
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
}

function RangeControl({
  label,
  valueLabel,
  min,
  max,
  step,
  value,
  onChange,
  onPointerDown,
}: {
  label: string;
  valueLabel: string;
  min: number;
  max: number;
  step: number;
  value: number;
  onChange: (value: number) => void;
  onPointerDown?: () => void;
}) {
  const progress = ((value - min) / (max - min)) * 100;

  return (
    <label className="control">
      <span className="control-label">
        <span>{label}</span>
        <output>{valueLabel}</output>
      </span>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        style={{ "--range-progress": `${progress}%` } as React.CSSProperties}
        onChange={(event) => onChange(Number(event.target.value))}
        onPointerDown={onPointerDown}
        aria-label={label}
      />
    </label>
  );
}

function Metric({
  value,
  label,
  tone = "default",
}: {
  value: string;
  label: string;
  tone?: "default" | "green" | "amber" | "blue";
}) {
  return (
    <div className={`metric metric-${tone}`}>
      <strong>{value}</strong>
      <span>{label}</span>
    </div>
  );
}

function RoomScene({ hour, clouds }: { hour: number; clouds: number }) {
  const ambient = ambientLight(hour, clouds);
  const pwm = pwmValue(hour, clouds);
  const brightness = pwm / 255;
  const sunStrength = sunlight(hour) * (1 - (0.8 * clouds) / 100);
  const wallLight = Math.max(ambient / 100, brightness * 0.72);
  const wall = `rgb(${Math.round(17 + 174 * wallLight)}, ${Math.round(
    30 + 179 * wallLight,
  )}, ${Math.round(47 + 184 * wallLight)})`;

  return (
    <div className="room-wrap">
      <svg
        className="room"
        viewBox="0 0 700 420"
        role="img"
        aria-label="Habitación con una ventana y una lámpara cuyo brillo cambia según la luz natural."
      >
        <defs>
          <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#6db7f0" />
            <stop offset="1" stopColor="#e6f3ff" />
          </linearGradient>
          <linearGradient id="floor" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#9aa9b5" />
            <stop offset="1" stopColor="#667682" />
          </linearGradient>
          <radialGradient id="lampGlow">
            <stop offset="0" stopColor="#fff4b8" stopOpacity="0.92" />
            <stop offset="0.42" stopColor="#ffd867" stopOpacity="0.44" />
            <stop offset="1" stopColor="#ffc94a" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="sunGlow">
            <stop offset="0" stopColor="#fff8c6" stopOpacity="1" />
            <stop offset="0.25" stopColor="#ffe66f" stopOpacity="0.88" />
            <stop offset="1" stopColor="#ffe66f" stopOpacity="0" />
          </radialGradient>
          <filter id="softBlur">
            <feGaussianBlur stdDeviation="8" />
          </filter>
        </defs>

        <rect width="700" height="326" fill={wall} />
        <rect y="326" width="700" height="94" fill="url(#floor)" />
        <path d="M0 326H700" stroke="#70818e" strokeWidth="5" />

        <rect
          x="72"
          y="62"
          width="238"
          height="192"
          rx="4"
          fill="#263c50"
          stroke="#dce7eb"
          strokeWidth="13"
        />
        <rect
          x="80"
          y="70"
          width="222"
          height="176"
          fill="url(#sky)"
          opacity={0.14 + sunStrength * 0.86}
        />
        <circle cx="190" cy="149" r="72" fill="url(#sunGlow)" opacity={sunStrength} />
        <circle cx="190" cy="149" r="24" fill="#fff3a2" opacity={sunStrength} />
        <path d="M191 68V246M80 158H302" stroke="#dce7eb" strokeWidth="8" />
        <path d="M67 260H316" stroke="#556c7b" strokeWidth="12" />

        <circle
          cx="524"
          cy="151"
          r={85 + brightness * 76}
          fill="url(#lampGlow)"
          opacity={brightness}
          filter="url(#softBlur)"
        />
        <path d="M524 0V91" stroke="#263642" strokeWidth="6" />
        <path d="M481 92H567L589 141H459L481 92Z" fill="#24343f" stroke="#121d25" strokeWidth="4" />
        <ellipse
          cx="524"
          cy="141"
          rx="64"
          ry="10"
          fill="#f5d977"
          opacity={0.16 + brightness * 0.84}
        />
        <circle cx="524" cy="145" r="17" fill="#fff0a2" opacity={Math.max(0.18, brightness)} />

        <rect x="434" y="304" width="242" height="24" rx="5" fill="#465966" />
        <path d="M458 328L446 420M650 328L662 420" stroke="#3b4b55" strokeWidth="13" />
        <rect x="470" y="278" width="75" height="26" rx="4" fill="#354752" />
        <circle cx="490" cy="291" r="4" fill="#66dfbd" />
        <path d="M558 304V246H622V304" fill="#526875" />
        <path d="M567 258H612" stroke="#a9bbc5" strokeWidth="5" />

        <g className="scene-label">
          <rect x="24" y="20" width="122" height="34" rx="17" fill="#10202c" fillOpacity="0.68" />
          <circle cx="43" cy="37" r="5" fill="#68e0bc" />
          <text x="56" y="42" fill="#f5fbff" fontSize="14" fontWeight="650">
            EN TIEMPO REAL
          </text>
        </g>
      </svg>

      <div className="room-status">
        <span>
          <i className="status-dot" />
          Sensor LDR activo
        </span>
        <strong>{Math.round(ambient)}% luz natural</strong>
      </div>
    </div>
  );
}

function EnergyChart({ hour, clouds }: { hour: number; clouds: number }) {
  const left = 45;
  const right = 15;
  const top = 17;
  const bottom = 34;
  const width = 720;
  const height = 260;
  const chartWidth = width - left - right;
  const chartHeight = height - top - bottom;
  const x = (value: number) => left + (value / 24) * chartWidth;
  const y = (value: number) => top + chartHeight * (1 - value / 100);

  const makePath = (getValue: (value: number) => number) => {
    let path = "";
    for (let current = 0; current <= 24.001; current += 0.2) {
      path += `${current === 0 ? "M" : "L"}${x(current).toFixed(2)},${y(getValue(current)).toFixed(
        2,
      )} `;
    }
    return path;
  };

  const ambientPath = makePath((value) => ambientLight(value, clouds));
  const smartPath = makePath((value) => (pwmValue(value, clouds) / 255) * 100);
  const traditionalPath = `M${x(0)},${y(100)} L${x(24)},${y(100)}`;

  return (
    <div className="chart-shell">
      <svg
        className="chart"
        viewBox={`0 0 ${width} ${height}`}
        role="img"
        aria-label="Gráfico diario de la luz ambiente y el brillo de las lámparas."
      >
        <defs>
          <linearGradient id="ambientArea" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#f2bb45" stopOpacity="0.2" />
            <stop offset="1" stopColor="#f2bb45" stopOpacity="0" />
          </linearGradient>
        </defs>
        {[0, 50, 100].map((value) => (
          <g key={value}>
            <line x1={left} y1={y(value)} x2={width - right} y2={y(value)} className="chart-grid" />
            <text x={left - 10} y={y(value) + 4} textAnchor="end" className="chart-axis">
              {value}%
            </text>
          </g>
        ))}
        {[0, 6, 12, 18, 24].map((value) => (
          <text
            key={value}
            x={x(value)}
            y={height - 8}
            textAnchor={value === 0 ? "start" : value === 24 ? "end" : "middle"}
            className="chart-axis"
          >
            {value}h
          </text>
        ))}
        <path d={`${ambientPath} L${x(24)},${y(0)} L${x(0)},${y(0)} Z`} fill="url(#ambientArea)" />
        <path d={traditionalPath} className="chart-traditional" />
        <path d={ambientPath} className="chart-ambient" />
        <path d={smartPath} className="chart-smart" />
        <line x1={x(hour)} y1={top} x2={x(hour)} y2={y(0)} className="chart-now" />
        <circle
          cx={x(hour)}
          cy={y(ambientLight(hour, clouds))}
          r="5"
          className="chart-point chart-point-ambient"
        />
        <circle
          cx={x(hour)}
          cy={y((pwmValue(hour, clouds) / 255) * 100)}
          r="5"
          className="chart-point chart-point-smart"
        />
      </svg>
    </div>
  );
}

function App() {
  const [hour, setHour] = useState(12);
  const [clouds, setClouds] = useState(20);
  const [power, setPower] = useState(9);
  const [playing, setPlaying] = useState(false);
  const frameRef = useRef<number | null>(null);

  useEffect(() => {
    if (!playing) return;

    let previous: number | null = null;
    const animate = (time: number) => {
      if (previous === null) previous = time;
      const elapsed = time - previous;
      previous = time;

      setHour((current) => {
        const next = current + elapsed / 500;
        if (next >= 24) {
          setPlaying(false);
          return 24;
        }
        return next;
      });
      frameRef.current = requestAnimationFrame(animate);
    };

    frameRef.current = requestAnimationFrame(animate);
    return () => {
      if (frameRef.current !== null) cancelAnimationFrame(frameRef.current);
    };
  }, [playing]);

  const current = useMemo(() => {
    const ambient = ambientLight(hour, clouds);
    const pwm = pwmValue(hour, clouds);
    return {
      ambient,
      pwm,
      watts: (power * pwm) / 255,
    };
  }, [hour, clouds, power]);

  const energy = useMemo(() => calculateEnergy(hour, clouds, power), [hour, clouds, power]);
  const dailyEnergy = useMemo(() => calculateEnergy(24, clouds, power), [clouds, power]);
  const savings =
    energy.traditional > 0 ? ((energy.traditional - energy.smart) / energy.traditional) * 100 : 0;
  const monthlySavings = ((dailyEnergy.traditional - dailyEnergy.smart) * 30) / 1000;

  const togglePlayback = () => {
    if (!playing && hour >= 24) setHour(0);
    setPlaying((currentPlaying) => !currentPlaying);
  };

  const reset = () => {
    setPlaying(false);
    setHour(12);
    setClouds(20);
    setPower(9);
  };

  return (
    <main>
      <header className="hero">
        <div className="brand">
          <span className="brand-mark" aria-hidden="true">
            <span />
          </span>
          <span>LABENERGY</span>
          <i />
          <span className="brand-tag">Simulador interactivo</span>
        </div>
        <div className="eyebrow">Eficiencia energética, explicada con luz</div>
        <h1>
          ¿Cuánta energía ahorra una lámpara que <em>mide la luz?</em>
        </h1>
        <p className="lead">
          Explora cómo una lámpara inteligente ajusta su brillo a la luz natural y compárala con una
          lámpara tradicional siempre encendida al 100%.
        </p>
      </header>

      <section className="simulator card">
        <div className="simulator-main">
          <RoomScene hour={hour} clouds={clouds} />
        </div>
        <div className="control-panel">
          <div className="section-heading compact">
            <div>
              <span className="kicker">CONFIGURA EL ESCENARIO</span>
              <h2>Controla la luz</h2>
            </div>
            <span className="live-pill">
              <i />
              En vivo
            </span>
          </div>

          <RangeControl
            label="Hora del día"
            valueLabel={formatHour(hour)}
            min={0}
            max={24}
            step={0.05}
            value={hour}
            onChange={setHour}
            onPointerDown={() => setPlaying(false)}
          />
          <RangeControl
            label="Nubosidad"
            valueLabel={`${Math.round(clouds)}%`}
            min={0}
            max={100}
            step={1}
            value={clouds}
            onChange={setClouds}
          />
          <RangeControl
            label="Potencia máxima"
            valueLabel={`${power} W`}
            min={3}
            max={20}
            step={1}
            value={power}
            onChange={setPower}
          />

          <div className="actions">
            <button className="primary-button" type="button" onClick={togglePlayback}>
              <span className={playing ? "pause-icon" : "play-icon"} aria-hidden="true" />
              {playing ? "Pausar simulación" : "Reproducir el día"}
            </button>
            <button className="secondary-button" type="button" onClick={reset}>
              Reiniciar
            </button>
          </div>
        </div>
      </section>

      <section className="section-block">
        <div className="section-heading">
          <div>
            <span className="kicker">LECTURAS DEL SENSOR</span>
            <h2>Lo que pasa ahora</h2>
          </div>
          <span className="use-status active">
            <i />
            Lámpara activa
          </span>
        </div>
        <div className="metrics-grid">
          <Metric value={`${Math.round(current.ambient)}%`} label="Luz ambiente" tone="amber" />
          <Metric value={String(current.pwm)} label="PWM · 0–255" tone="blue" />
          <Metric value={`${current.watts.toFixed(1)} W`} label="Potencia ahora" tone="green" />
          <Metric value="24 h" label="Siempre encendida" />
        </div>
      </section>

      <section className="energy-card">
        <div className="energy-copy">
          <span className="kicker light">AHORRO ACUMULADO HASTA AHORA</span>
          <div className="savings-value">{savings.toFixed(0)}%</div>
          <h2>menos energía consumida</h2>
          <p>
            La lámpara inteligente ha usado <strong>{energy.smart.toFixed(1)} Wh</strong> frente a{" "}
            <strong>{energy.traditional.toFixed(1)} Wh</strong> de una lámpara tradicional.
          </p>
        </div>
        <div className="monthly-card">
          <span>PROYECCIÓN MENSUAL</span>
          <strong>{monthlySavings.toFixed(1)} kWh</strong>
          <p>de ahorro si todos los días fueran como este.</p>
          <div className="schedule">
            <i />
            Encendida las 24 horas
          </div>
        </div>
      </section>

      <section className="chart-card card">
        <div className="section-heading chart-heading">
          <div>
            <span className="kicker">COMPORTAMIENTO DURANTE EL DÍA</span>
            <h2>Luz natural y brillo de la lámpara</h2>
          </div>
          <div className="legend">
            <span>
              <i className="legend-ambient" />
              Luz ambiente
            </span>
            <span>
              <i className="legend-smart" />
              Lámpara inteligente
            </span>
            <span>
              <i className="legend-traditional" />
              Tradicional
            </span>
          </div>
        </div>
        <EnergyChart hour={hour} clouds={clouds} />
      </section>

      <section className="formula-card card">
        <div className="formula-intro">
          <span className="kicker">BAJO EL CAPÓ</span>
          <h2>Cómo se calcula</h2>
          <p>
            El sensor LDR mide la luz. El ESP32 convierte esa medida en brillo y calcula el consumo
            energético en tiempo real.
          </p>
        </div>
        <div className="formulas">
          <div>
            <span>01</span>
            <code>PWM = máx(1, 255 · (1 − luz / 100))</code>
          </div>
          <div>
            <span>02</span>
            <code>P = Pmax · PWM / 255</code>
          </div>
          <div>
            <span>03</span>
            <code>E = Σ P · Δt</code>
          </div>
          <div>
            <span>04</span>
            <code>Ahorro = (Etrad − Eint) / Etrad · 100</code>
          </div>
        </div>
      </section>

      <footer>
        <div className="brand footer-brand">
          <span className="brand-mark" aria-hidden="true">
            <span />
          </span>
          <span>LABENERGY</span>
        </div>
        <p>
          Simulación educativa. Los valores reales dependen del sensor LDR, del LED y de la
          calibración con un luxómetro.
        </p>
      </footer>
    </main>
  );
}

export default App;
